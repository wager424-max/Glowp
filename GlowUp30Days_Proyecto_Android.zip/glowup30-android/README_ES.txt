GLOW UP 30 DAYS — PROYECTO ANDROID

Este paquete contiene el proyecto fuente de una aplicación Android. No incluye un APK ya compilado.

QUÉ INCLUYE
- Rutina diaria de mañana, durante el día y noche.
- Cuidado suave del cabello rizado.
- Calendario de 30 días.
- Casillas para marcar hábitos.
- Progreso guardado localmente en el teléfono mediante el almacenamiento del navegador integrado.
- Reinicio voluntario del progreso.

CÓMO GENERAR EL APK EN UNA PC
1. Instala Android Studio desde el sitio oficial de Android Developers.
2. Descomprime este ZIP.
3. Abre Android Studio y selecciona Open; elige la carpeta GlowUp30Days (la carpeta que contiene settings.gradle).
4. Acepta la sincronización de Gradle y permite que Android Studio descargue los componentes de Android que solicite.
5. En el menú, selecciona Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Cuando termine, Android Studio mostrará un aviso para localizar el APK. Normalmente queda en app/build/outputs/apk/debug/app-debug.apk.
7. Copia ese APK a tu teléfono Android y ábrelo para instalarlo. Puede que Android te pida autorizar la instalación desde esa fuente.

REQUISITOS
- Android Studio actualizado.
- JDK compatible con la versión de Android Gradle Plugin (Android Studio incluye uno).
- Conexión a Internet la primera vez para que Gradle descargue el plugin y el SDK de Android.

NOTA
El proyecto está preparado para compilarse con compileSdk 35 y Android Gradle Plugin 8.7.3. No he podido generar ni probar un APK en este entorno porque no tiene Android SDK ni Gradle instalados.
